// Feature tags
// Load help tooltip for specific features
const betaFeatures = document.querySelectorAll(".beta");

for (let i = 0; i < betaFeatures.length; i++) {
	betaFeatures[i].setAttribute('title', "This feature is still being tested and improved.");
}