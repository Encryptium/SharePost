function removeInvalidChars(name){
	var currInput = document.getElementsByName(name)[0].value;

  var newInput = currInput.replace(/[^A-Za-z0-9!\-~|]/g,'');

  document.getElementsByName(name)[0].value = newInput;
}

/*
var requestUsername = document.getElementsByName("username")[0];
var submitBtn = document.querySelector("[type='submit']");
var registerMessage = document.getElementById("register-message");

requestUsername.addEventListener('keyup', () => {
	fetch(`/api/v1/portal?action=check_username&username=${requestUsername.value}`)
  .then(response => response.json())
  .then(data => {
		if (data['success']) {
			submitBtn.disabled = false;
			registerMessage.innerHTML = data['message'];
		} else {
			submitBtn.disabled = true;
			registerMessage.innerHTML = data['message'];
		}
	});
});
*/